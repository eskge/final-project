
import { PipelineResult, Prediction } from '../types';

const delay = (ms: number) => new Promise(res => setTimeout(res, ms));

export const runFullPipeline = async (onProgress: (message: string) => void): Promise<PipelineResult> => {
  onProgress('Starting pipeline execution...');
  await delay(1000);
  onProgress('1. Data Ingestion: Loading raw data...');
  await delay(1500);
  onProgress('Raw data loaded successfully.');
  
  await delay(500);
  onProgress('2. Data Profiling & Quality Assessment...');
  await delay(2000);
  onProgress('Profiling report generated. No critical issues found.');

  await delay(500);
  onProgress('3. Data Cleaning & Preprocessing...');
  await delay(1500);
  onProgress('Data cleaned and preprocessed.');

  await delay(500);
  onProgress('4. Feature Engineering...');
  await delay(1000);
  onProgress('New features created.');

  await delay(500);
  onProgress('5. Model Training & Evaluation...');
  onProgress('Starting hyperparameter tuning with RandomizedSearchCV...');
  await delay(4000);
  onProgress('Hyperparameter tuning finished. Training final model...');
  await delay(2000);
  onProgress('Model trained and evaluated successfully.');
  
  onProgress('Pipeline Execution Complete!');

  return {
    metrics: {
      accuracy: 0.8147,
      precision: 0.6723,
      recall: 0.5988,
      f1: 0.6335,
      roc_auc: 0.8521,
    },
    confusionMatrix: [[894, 142], [128, 245]],
  };
};

export const predictNewData = async (file: File): Promise<Prediction[]> => {
  await delay(1000);
  console.log(`Simulating prediction for file: ${file.name}`);
  await delay(2000);

  // Generate mock predictions
  const numPredictions = Math.floor(Math.random() * 20) + 5;
  const predictions: Prediction[] = [];
  for (let i = 1; i <= numPredictions; i++) {
    const churn = Math.random() > 0.75;
    predictions.push({
      customerID: `CUST-${String(1000 + i).padStart(4, '0')}`,
      Predicted_Churn: churn ? 'Yes' : 'No',
      Churn_Probability: churn ? (Math.random() * 0.4 + 0.55).toFixed(2) : (Math.random() * 0.35).toFixed(2),
    });
  }
  return predictions;
};
